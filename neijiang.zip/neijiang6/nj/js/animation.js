/**
 * Created by yy on 2019/3/8.
 */
    $(function (){
        var $li = $("li.general,li.person,li.science,li.job,li.resource");
        $li.mouseenter(function (){
            $(this).children("ul").slideDown(200);
        });
        $li.mouseleave(function (){
            $(this).children("ul").hide();
        });
    });






